"""Account Invoice Line Model."""

from odoo import fields, models


class AccountMoveLine(models.Model):
    """Account Invoice Line Model."""

    _inherit = "account.move.line"

    partner_parent_id = fields.Many2one(related="partner_id.parent_id", string="Customer Parent Name")
    team_id = fields.Many2one(related="move_id.team_id", string="Sales Team")
    x_studio_partner_salesperson = fields.Many2one(related="move_id.partner_id.user_id", string="Partner Salesperson")
    x_studio_customer_name = fields.Char(related="move_id.partner_id.name", string="Customer Name")
    x_studio_sales_person = fields.Many2one(related="move_id.user_id", string="Salesperson",)
    x_studio_signed_amount = fields.Monetary(related="move_id.amount_total_signed", string="Signed Amount")
    x_studio_invoice_reference_status = fields.Selection(related="move_id.state", string="Invoice Reference Status")
    x_studio_state = fields.Many2one(related="move_id.partner_id.state_id", string="State")
    x_studio_country = fields.Many2one(related="move_id.partner_id.country_id", string="Country")
    x_studio_invoice_date = fields.Date(related="move_id.invoice_date", string='Invoice Date')
