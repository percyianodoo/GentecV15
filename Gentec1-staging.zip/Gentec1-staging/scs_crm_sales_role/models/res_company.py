"""Res Company Model."""

from odoo import api, models


class ResCompany(models.Model):
    """Res Company Model Inherit."""

    _inherit = "res.company"

    """Method to remove date end from price list item."""
    # self.env.cr.execute("update product_pricelist_item set date_end=null")

    def update_sales_team_in_quote_sales_order(self):
        """Method to set sales team in Quotation/Sale Orders."""
        sale_obj = self.env['sale.order']
        sales_ords = sale_obj.search([('partner_id', '!=', False), ('team_id', '=', False)])
        for sale_ord in sales_ords:
            if sale_ord.partner_id.team_id:
                sale_ord.write({'team_id': sale_ord.partner_id.team_id.id or False})
            elif sale_ord.partner_id.parent_id and sale_ord.partner_id.parent_id.team_id:
                sale_ord.write({'team_id': sale_ord.partner_id.parent_id.team_id.id or False})

    def update_sales_team_in_account_invoice(self):
        """Method to set sales team in Sales Invoices."""
        invoice_obj = self.env['account.move']
        sales_invoices = invoice_obj.search([('partner_id', '!=', False), ('team_id', '=', False), ('move_type', 'in', ['out_invoice', 'out_refund'])])
        for sale_inv in sales_invoices:
            if sale_inv.partner_id:
                if sale_inv.partner_id.team_id:
                    sale_inv.write({
                        'team_id': sale_inv.partner_id.team_id.id or False
                    })
                elif sale_inv.partner_id.parent_id and sale_inv.partner_id.parent_id.team_id:
                    sale_inv.write({
                        'team_id':
                        sale_inv.partner_id.parent_id.team_id.id or False
                    })

    def update_sales_person_in_quote_sales_order(self):
        """Method to update sales person reference in sale order."""
        """Due to the studio fields that reference is missing need to fix."""
        sale_obj = self.env['sale.order']
        sales_ords = sale_obj.search([
            ('partner_id', '!=', False),
            ('user_id', '=', False)])
        for sale_ord in sales_ords:
            if sale_ord.partner_id.user_id:
                sale_ord.write({
                    'user_id': sale_ord.partner_id.user_id.id or False
                })
            elif sale_ord.partner_id.parent_id and sale_ord.partner_id.parent_id.user_id:
                sale_ord.write({
                    'user_id':
                    sale_ord.partner_id.parent_id.user_id.id or False
                })

    def update_sales_person_in_account_invoice(self):
        """Method to update sales person reference in account invoice."""
        """Due to the studio fields that reference is missing need to fix."""
        invoice_obj = self.env['account.move']
        cust_invs = invoice_obj.search([('partner_id', '!=', False), ('user_id', '=', False), ('move_type', 'in', ['out_invoice', 'out_refund'])])
        for cust_inv in cust_invs:
            if cust_inv.partner_id.user_id:
                cust_inv.write({
                    'user_id': cust_inv.partner_id.user_id.id or False
                })
            elif cust_inv.partner_id.parent_id and cust_inv.partner_id.parent_id.user_id:
                cust_inv.write({
                    'user_id':
                    cust_inv.partner_id.parent_id.user_id.id or False
                })

    def update_sales_person_in_account_invoice_lines(self):
        """Method to update sales person reference in account invoice lines."""
        """Due to the studio fields that reference is missing need to fix."""
        inv_line_obj = self.env['account.move.line']
        inv_lines = inv_line_obj.search([('x_studio_sales_person', '=', False), ('move_id', '!=', False), ('move_id.invoice_user_id', '!=', False)])
        for inv_line in inv_lines:
            inv_line.write({
                'x_studio_sales_person': inv_line.move_id.user_id.id
            })

    def update_partner_sales_person_in_account_invoice_lines(self):
        """To update partner sales person for account invoice lines."""
        """Due to the studio fields that reference is missing need to fix."""
        inv_line_obj = self.env['account.move.line']
        inv_lines = inv_line_obj.search([('x_studio_partner_salesperson', '=', False), ('move_id', '!=', False), ('move_id.partner_id', '!=', False)])
        for inv_line in inv_lines:
            if inv_line.move_id.partner_id.user_id:
                inv_line.write({
                    'x_studio_partner_salesperson':
                    inv_line.move_id.partner_id.user_id.id
                })
            if not inv_line.move_id.partner_id.user_id and inv_line.move_id.partner_id.parent_id and inv_line.move_id.partner_id.parent_id.user_id:
                inv_line.write({
                    'x_studio_partner_salesperson':
                    inv_line.move_id.partner_id.parent_id.user_id.id
                })

    def update_state_id_in_account_invoice_lines(self):
        """Method to update state reference in account invoice lines."""
        """Due to the studio fields that reference is missing need to fix."""
        inv_line_obj = self.env['account.move.line']
        inv_lines = inv_line_obj.search([('x_studio_state', '=', False), ('move_id', '!=', False), ('move_id.partner_id', '!=', False)])
        for inv_line in inv_lines:
            if inv_line.move_id.partner_id and inv_line.move_id.partner_id.state_id:
                inv_line.write({
                    'x_studio_state':
                    inv_line.move_id.partner_id.state_id.id
                })

    def update_country_id_in_account_invoice_lines(self):
        """Method to update country reference in account invoice lines."""
        """Due to the studio fields that reference is missing need to fix."""
        inv_line_obj = self.env['account.move.line']
        inv_lines = inv_line_obj.search([('x_studio_country', '=', False), ('move_id', '!=', False), ('move_id.partner_id', '!=', False)])
        for inv_line in inv_lines:
            if inv_line.move_id.partner_id and inv_line.move_id.partner_id.country_id:
                inv_line.write({
                    'x_studio_country': inv_line.move_id.partner_id.country_id.id
                })
