"""Sales Billed Invoice Target and Sales Billed Invoice Target Team Model."""

import pytz
from pytz import timezone
# import calendar
from datetime import datetime
from odoo.tools import date_utils
from odoo import api, fields, models, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as DTF
from odoo.exceptions import ValidationError


def convert_dt_in_utc(convert_dt, user_tz):
    now_utc_tz = convert_dt.astimezone(timezone('UTC'))
    return now_utc_tz


class SalesBilledInvoiceTargetTeam(models.Model):
    _name = "sales.billed.invoice.target.team"
    _description = "Sales Billed Invoice Target Team"
    _rec_name = 'team_id'
    _order = 'id desc'

    sales_team_target = fields.Float(string="Sales Team Target")
    time_span = fields.Selection([('monthly', 'Monthly'), ('quarterly', 'Quarterly'), ('yearly', 'Yearly')], string="Time Span", default="monthly")
    date_from = fields.Date(string="Start Date")
    date_to = fields.Date(string="End Date")
    team_id = fields.Many2one("crm.team", string="Team")
    regions = fields.Selection(related="team_id.regions", string="Regions", store=True)
    sales_ord_trg_achived = fields.Float(compute="get_sales_teams_orders_and_invoice_info", store=True, string="Sales Order Target Achived")
    billed_inv_trg_achived = fields.Float(compute="get_sales_teams_orders_and_invoice_info", store=True, string="Billed Invoice Target Achived")
    sale_team_order_ids = fields.Many2many("sale.order", "sales_order_team_target_rel", "sale_order_team_trg_id", "sale_order_id", store=True, string="Sale Teams Orders", compute='get_sales_teams_orders_and_invoice_info')
    sale_invoice_ids = fields.Many2many("account.move", "sales_invoice_team_target_rel", "sale_invoice_team_trg_id", "sale_invoice_id", store=True, string="Sale Teams Invoices", compute='get_sales_teams_orders_and_invoice_info')
    state = fields.Selection([('draft', 'Draft'), ('open', 'In Progress'), ('cancel', 'Cancelled'), ('done', 'Done')], default="draft", string="Status")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.user and self.env.user.company_id)
    country_id = fields.Many2one("res.country", string="Country")
    state_id = fields.Many2one("res.country.state", string="State")

    @api.onchange('country_id')
    def onchange_country_id(self):
        self.state_id = False

    @api.onchange('date_from')
    def onchange_date_from(self):
        if self.date_from and self.date_to:
            self.date_to = False

    @api.constrains('date_from', 'date_to')
    def _check_from_to_date(self):
        for rec in self:
            if rec.date_from > rec.date_to:
                raise ValidationError(_("Start Date must be less than Or Equal to End Date !!"))

    @api.constrains('date_from', 'date_to', 'team_id')
    def _check_duplicate_sales_team_target(self):
        team_trg_obj = self.env['sales.billed.invoice.target.team']
        for rec in self:
            dup_trg_rec = team_trg_obj.search([('id', '!=', rec.id), ('team_id', '=', rec.team_id and rec.team_id.id), ('date_from', '>=', rec.date_from), ('date_to', '<=', rec.date_to)])
            if dup_trg_rec:
                raise ValidationError(
                    _("You can't create sales team target twice for same team with same date range !!"))

    @api.onchange('company_id')
    def onchange_company_id(self):
        if self.company_id and self.team_id:
            if self.team_id.company_id and self.team_id.company_id.id != self.company_id.id:
                self.team_id = False

    def action_open_target(self):
        for team_trg in self:
            team_trg.state = 'open'

    def action_set_to_draft_target(self):
        for team_trg in self:
            team_trg.state = 'draft'

    def action_set_to_done(self):
        for team_trg in self:
            team_trg.state = 'done'

        for team_trg in self:
            team_trg.state = 'cancel'

    def _get_all_teams(self, team_id=False):
        self.ensure_one()
        crm_team_obj = self.env['crm.team']
        team_ids = []
        if team_id:
            team_ids = crm_team_obj.search([('id', 'child_of', team_id.id)]).ids
        return team_ids

    def get_sales_teams_orders_and_invoice_info(self):
        """Method to get the team orders and invoice info."""
        sale_obj = self.env['sale.order']
        inv_obj = self.env['account.move']
        for sale_team_trg in self:
            sale_team_trg.sales_ord_trg_achived = False
            sale_team_trg.billed_inv_trg_achived = False
            sale_team_trg.sale_team_order_ids = False
            sale_team_trg.sale_invoice_ids = False

            sale_team_trg.sale_team_order_ids = [(6, 0, [])]
            sale_team_trg.sale_invoice_ids = [(6, 0, [])]
            team_ids = []
            if sale_team_trg.team_id:
                team_ids = sale_team_trg._get_all_teams(sale_team_trg.team_id)
            if team_ids:
                st_dt = sale_team_trg.date_from
                en_dt = sale_team_trg.date_to
                if not st_dt or not en_dt:
                    continue
                if sale_team_trg.date_from:
                    st_dt = st_dt.strftime('%Y-%m-%d')
                    st_dt = datetime.strptime(st_dt, '%Y-%m-%d').strftime('%Y-%m-%d 00:00:00')
                    st_dt = datetime.strptime(st_dt, DTF)

                    tz_t = pytz.timezone(self.env.user.tz)
                    st_dt = st_dt.replace(tzinfo=tz_t)
                    st_dt = convert_dt_in_utc(st_dt, self.env.user.tz)
                if sale_team_trg.date_to:
                    en_dt = en_dt.strftime('%Y-%m-%d')
                    en_dt = datetime.strptime(en_dt, '%Y-%m-%d').strftime('%Y-%m-%d 23:59:59')
                    en_dt = datetime.strptime(en_dt, DTF)

                    tz_t = pytz.timezone(self.env.user.tz)
                    en_dt = en_dt.replace(tzinfo=tz_t)
                    en_dt = convert_dt_in_utc(en_dt, self.env.user.tz)
                sales = sale_obj.search([
                    ('create_date', '>=', st_dt),
                    ('create_date', '<=', en_dt),
                    ('team_id', 'in', team_ids),
                    # ('state', 'in', ['sale', 'done']),
                    ('state', 'not in', ['cancel']),
                    ('client_order_ref', '!=', False),
                    ('company_id', '=', sale_team_trg.company_id and sale_team_trg.company_id.id or False)])

                sale_team_trg.sale_team_order_ids = [(6, 0, sales.ids)]
                sale_team_trg.sales_ord_trg_achived = sum([sale.amount_untaxed for sale in sales]) or 0.0

                invoices = inv_obj.search([
                    ('invoice_date', '>=', sale_team_trg.date_from),
                    ('invoice_date', '<=', sale_team_trg.date_to),
                    ('move_type', '=', 'out_invoice'),
                    ('team_id', 'in', team_ids),
                    ('state', 'in', ['open', 'in_payment', 'paid']),
                    ('company_id', '=', sale_team_trg.company_id and
                        sale_team_trg.company_id.id or False)])
                sale_team_trg.sale_invoice_ids = [(6, 0, invoices.ids)]
                sale_team_trg.billed_inv_trg_achived = sum([sale_inv.amount_untaxed for sale_inv in invoices]) or 0.0

    def get_timespan_start_end_dt(self):
        curr_dt = datetime.now().date()
        s_date = date_utils.start_of(curr_dt, 'month')
        e_date = date_utils.end_of(curr_dt, 'month')
        if self.time_span:
            if self.time_span == 'monthly':
                s_date = date_utils.start_of(curr_dt, 'month')
                e_date = date_utils.end_of(curr_dt, 'month')
            elif self.time_span == 'quarterly':
                s_date = date_utils.start_of(curr_dt, 'quarter')
                e_date = date_utils.end_of(curr_dt, 'quarter')
            elif self.time_span == 'yearly':
                s_date = date_utils.start_of(curr_dt, 'year')
                e_date = date_utils.end_of(curr_dt, 'year')
        return s_date, e_date

    @api.onchange('time_span')
    def onchange_time_span(self):
        s_date, e_date = self.get_timespan_start_end_dt()
        if s_date and e_date:
            self.date_from = s_date
            self.date_to = e_date


class SalesBilledInvoiceTarget(models.Model):
    _name = "sales.billed.invoice.target"
    _description = "Sales Billed Invoice Target Person"
    _rec_name = 'sales_user_id'
    _order = 'id desc'

    sales_user_id = fields.Many2one("res.users", string="Sales Person")
    sales_person_target = fields.Float(string="Sales Person Target")
    time_span = fields.Selection([('monthly', 'Monthly'), ('quarterly', 'Quarterly'), ('yearly', 'Yearly')], string="Time Span", default="monthly")
    date_from = fields.Date(string="Start Date")
    date_to = fields.Date(string="End Date")
    sales_ord_trg_achived = fields.Float(compute="get_sales_persons_orders_and_invoice_info", string="Sales Order Target Achived")
    billed_inv_trg_achived = fields.Float(compute="get_sales_persons_orders_and_invoice_info", string="Billed Invoice Target Achived")
    sale_person_order_ids = fields.Many2many("sale.order", "sales_ord_person_target_rel", "sale_ord_person_trg_id", "sale_order_id", string="Sale Teams Orders", compute='get_sales_persons_orders_and_invoice_info')
    sale_invoice_ids = fields.Many2many("account.move", "sales_invoice_person_target_rel", "sale_invoice_person_trg_id", "sale_invoice_id", string="Sale Teams Invoices", compute='get_sales_persons_orders_and_invoice_info')
    state = fields.Selection([('draft', 'Draft'), ('open', 'In Progress'), ('cancel', 'Cancelled'), ('done', 'Done')], default="draft", string="Status")
    company_id = fields.Many2one("res.company", string="Company", default=lambda self: self.env.user and self.env.user.company_id)

    @api.onchange('date_from')
    def onchange_date_from(self):
        if self.date_from and self.date_to:
            self.date_to = False

    @api.onchange('company_id')
    def onchange_company_id(self):
        if self.company_id and self.sales_user_id:
            if self.sales_user_id.company_id and self.sales_user_id.company_id.id != self.company_id.id:
                self.sales_user_id = False

    @api.constrains('date_from', 'date_to')
    def _check_from_to_date(self):
        for rec in self:
            if rec.date_from > rec.date_to:
                raise ValidationError(_("Start Date must be less than Or Equal to End Date !!"))

    @api.constrains('date_from', 'date_to', 'sales_user_id')
    def _check_duplicate_sales_person_target(self):
        sales_per_trg_obj = self.env['sales.billed.invoice.target']
        for rec in self:
            dup_trg_rec = sales_per_trg_obj.search([('id', '!=', rec.id), ('sales_user_id', '=', rec.sales_user_id and rec.sales_user_id.id), ('date_from', '>=', rec.date_from), ('date_to', '<=', rec.date_to)])
            if dup_trg_rec:
                raise ValidationError(
                    _("You can't create salesperson target twice for same salesperson with same date range !!"))

    def action_open_target(self):
        for team_trg in self:
            team_trg.state = 'open'

    def action_set_to_draft_target(self):
        for team_trg in self:
            team_trg.state = 'draft'

    def action_set_to_done(self):
        for team_trg in self:
            team_trg.state = 'done'

    def action_set_to_cancel(self):
        for team_trg in self:
            team_trg.state = 'cancel'

    def get_timespan_start_end_dt(self):
        curr_dt = datetime.now().date()
        s_date = date_utils.start_of(curr_dt, 'month')
        e_date = date_utils.end_of(curr_dt, 'month')
        if self.time_span:
            if self.time_span == 'monthly':
                s_date = date_utils.start_of(curr_dt, 'month')
                e_date = date_utils.end_of(curr_dt, 'month')
            elif self.time_span == 'quarterly':
                s_date = date_utils.start_of(curr_dt, 'quarter')
                e_date = date_utils.end_of(curr_dt, 'quarter')
            elif self.time_span == 'yearly':
                s_date = date_utils.start_of(curr_dt, 'year')
                e_date = date_utils.end_of(curr_dt, 'year')
        return s_date, e_date

    @api.onchange('time_span')
    def onchange_time_span(self):
        s_date, e_date = self.get_timespan_start_end_dt()
        if s_date and e_date:
            self.date_from = s_date
            self.date_to = e_date

    def get_sales_persons_orders_and_invoice_info(self):
        sale_obj = self.env['sale.order']
        inv_obj = self.env['account.move']
        for sale_person_trg in self:
            sale_team_order_ids.sales_ord_trg_achived = False
            sale_team_order_ids.billed_inv_trg_achived = False
            sale_team_order_ids.sale_person_order_ids = False
            sale_team_order_ids.sale_invoice_ids = False

            sale_person_trg.sale_person_order_ids = [(6, 0, [])]
            sale_person_trg.sale_invoice_ids = [(6, 0, [])]
            sale_person = sale_person_trg.sales_user_id and sale_person_trg.sales_user_id.id or False
            st_dt = sale_person_trg.date_from
            en_dt = sale_person_trg.date_to
            if not st_dt or not en_dt:
                continue
            if sale_person_trg.date_from:
                st_dt = st_dt.strftime('%Y-%m-%d')
                st_dt = datetime.strptime(st_dt, '%Y-%m-%d').strftime('%Y-%m-%d 00:00:00')
                st_dt = datetime.strptime(st_dt, DTF)
                tz_t = pytz.timezone(self.env.user.tz)
                st_dt = st_dt.replace(tzinfo=tz_t)
                st_dt = convert_dt_in_utc(st_dt, self.env.user.tz)
            if sale_person_trg.date_to:
                en_dt = en_dt.strftime('%Y-%m-%d')
                en_dt = datetime.strptime(en_dt, '%Y-%m-%d').strftime('%Y-%m-%d 23:59:59')
                en_dt = datetime.strptime(en_dt, DTF)

                tz_t = pytz.timezone(self.env.user.tz)
                en_dt = en_dt.replace(tzinfo=tz_t)
                en_dt = convert_dt_in_utc(en_dt, self.env.user.tz)
            if sale_person:
                sales = sale_obj.search([
                    ('create_date', '>=', st_dt),
                    ('create_date', '<=', en_dt),
                    ('user_id', '=', sale_person),
                    ('client_order_ref', '!=', False),
                    ('company_id', '=', sale_person_trg.company_id and sale_person_trg.company_id.id or False),
                    ('state', 'in', ['sale', 'done']),
                ])
                sale_person_trg.sale_person_order_ids = [(6, 0, sales.ids)]
                sale_person_trg.sales_ord_trg_achived = sum([sale.amount_untaxed for sale in sales]) or 0.0

                invoices = inv_obj.search([('invoice_date', '>=', sale_person_trg.date_from), ('invoice_date', '<=', sale_person_trg.date_to), ('move_type', '=', 'out_invoice'), ('user_id', '=', sale_person), ('company_id', '=', sale_person_trg.company_id and sale_person_trg.company_id.id or False), ('state', 'in', ['open', 'in_payment', 'paid'])])
                sale_person_trg.sale_invoice_ids = [(6, 0, invoices.ids)]
                sale_person_trg.billed_inv_trg_achived = sum([sale_inv.amount_untaxed for sale_inv in invoices]) or 0.0

  