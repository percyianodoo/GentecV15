"""Initialize python files."""
# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

# from . import wiz_sales_team_target_report
from . import wiz_inv_sales_team_target_report
# from . import wiz_inv_state_sales_team_trg_rep
from . import wiz_non_parent_child_report
