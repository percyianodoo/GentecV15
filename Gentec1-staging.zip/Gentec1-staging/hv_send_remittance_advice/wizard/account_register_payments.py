from odoo import api, fields, models, _


class hv_account_register_payment(models.TransientModel):
    _inherit = "account.register.payments"

    def _prepare_payment_vals(self, invoices):
        values = super(hv_account_register_payment, self)._prepare_payment_vals(invoices)
        if self._context.get('batch_payment_id'):
            values.update({'batch_payment_id': self._context.get('batch_payment_id')})
        return values

    def create_payments(self):
        if self.payment_method_id.code == 'aba_ct':
            batch_payment = self.env['account.batch.payment'].create({
                'state': 'draft',
                'batch_type': 'outbound',
                'journal_id': self.journal_id.id,
                'payment_method_id': self.payment_method_id.id,
            })
            self = self.with_context(batch_payment_id=batch_payment.id)

        action_vals = super(hv_account_register_payment, self).create_payments()

        if self.payment_method_id.code == 'aba_ct':
            action_vals = {
                'name': _('Batch Payments'),
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'account.batch.payment',
                'view_id': False,
                'res_id': batch_payment.id,
                'type': 'ir.actions.act_window',
                'target': 'current',
            }

        return action_vals