from odoo import api, fields, models, _


class hv_batch_email_send(models.TransientModel):
    _name = "batch.payment.email.send"
    _inherit = "batch.payment.email.send.abstract"
    _description = 'Batch Payment Email Send'

    total = fields.Monetary(compute="_total")

    @api.depends('payment_ids')
    def _total(self):
        self.total = 0
        if self.payment_ids:
            for item in self.payment_ids:
                self.total += item.amount