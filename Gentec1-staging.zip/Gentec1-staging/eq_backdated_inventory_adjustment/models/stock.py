# -*- coding: utf-8 -*-
##############################################################################
#
# Copyright 2019 EquickERP
#
##############################################################################

from odoo import models, fields, api
from odoo.tools.float_utils import float_compare, float_is_zero


class stock_inventory(models.Model):
    _inherit = 'stock.quant'


    @api.model
    def _get_inventory_fields_write(self):
        """ Returns a list of fields user can edit when he want to edit a quant in `inventory_mode`.
        """
        fields = ['inventory_quantity', 'inventory_quantity_auto_apply', 'inventory_diff_quantity',
                  'inventory_date', 'user_id', 'inventory_quantity_set', 'is_outdated', 'is_backdated_inv', 'inv_backdated', 'backdated_remark',]
        return fields

    @api.model
    def _get_inventory_fields_create(self):
        """ Returns a list of fields user can edit when he want to create a quant in `inventory_mode`.
        """
        return ['product_id', 'location_id', 'lot_id', 'package_id', 'owner_id', 'inventory_date', 
        'is_backdated_inv', 'inv_backdated', 'backdated_remark', 'accounting_date'] + self._get_inventory_fields_write()

    inventory_date = fields.Date(
        'Scheduled Date', compute='_compute_inventory_date', store=True, readonly=False,
        help="Next date the On Hand Quantity should be counted.")
    is_backdated_inv = fields.Boolean(string="Is Backdated Inventory?",copy=False)
    inv_backdated = fields.Date(string="Inventory Backdate",copy=False)
    backdated_remark = fields.Char(string="Notes",copy=False)

    @api.depends('location_id')
    def _compute_inventory_date(self):
        quants = self.filtered(lambda q: not q.inventory_date and q.location_id.usage in ['internal', 'transit'])
        date_by_location = {loc: loc._get_next_inventory_date() for loc in quants.location_id}
        for quant in quants:
            quant.inventory_date = date_by_location[quant.location_id]


    @api.model
    def create(self, vals):
        res = super(stock_inventory, self).create(vals)
        if res.inv_backdated:
            res.inventory_date = res.inv_backdated
        return res

    # def _apply_inventory(self):
    #     res = super(stock_inventory, self)._apply_inventory()
    #     import pdb;pdb.set_trace()
    #     if self.inventory_date != self.inv_backdated:
    #         self.inventory_date = self.inv_backdated
    #     self.location_id.write({'last_inventory_date': self.inv_backdated})
    #     return res

    def _apply_inventory(self):
        move_vals = []
        if not self.user_has_groups('stock.group_stock_manager'):
            raise UserError(_('Only a stock manager can validate an inventory adjustment.'))
        for quant in self:
            # Create and validate a move so that the quant matches its `inventory_quantity`.
            if float_compare(quant.inventory_diff_quantity, 0, precision_rounding=quant.product_uom_id.rounding) > 0:
                move_vals.append(
                    quant._get_inventory_move_values(quant.inventory_diff_quantity,
                                                     quant.product_id.with_company(quant.company_id).property_stock_inventory,
                                                     quant.location_id))
            else:
                move_vals.append(
                    quant._get_inventory_move_values(-quant.inventory_diff_quantity,
                                                     quant.location_id,
                                                     quant.product_id.with_company(quant.company_id).property_stock_inventory,
                                                     out=True))
        moves = self.env['stock.move'].with_context(inventory_mode=False).create(move_vals)
        # import pdb;pdb.set_trace()
        moves._action_done()
        self.location_id.write({'last_inventory_date': fields.Date.today()})
        date_by_location = {loc: loc._get_next_inventory_date() for loc in self.mapped('location_id')}
        for quant in self:
            quant.inventory_date = date_by_location[quant.location_id]
        moves.date = self.inv_backdated
        moves.move_line_ids.date = self.inv_backdated
        self.write({'inventory_quantity': 0, 'user_id': False})
        self.write({'inventory_diff_quantity': 0})


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: