cancel stock picking
cancel stock pickings

cancel done stock picking
cancel done stock pickings

cancel transfer
cancel transfers

cancel stock move
cancel stock moves

cancel inventory adjustment
cancel inventory adjustments

cancel validated inventory adjustment

cancel scrap order
cancel scrap orders

cancel picking
cancel stock transfer

cancel sale
cancel done sale
cancel done sale order
cancel sale order

cancel purchase
cancel done purchase
cancel done purchase order
cancel sale purchase order

cancel inventory move
cancel inventory moves

