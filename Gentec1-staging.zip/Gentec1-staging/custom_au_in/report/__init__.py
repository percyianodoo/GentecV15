# -*- coding: utf-8 -*-

from . import custom_picking_report

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
