# -*- coding: utf-8 -*-
"""Inherited For Sale Margin."""

from odoo import api, fields, models, _

# class CheckValueAbs(models.AbstractModel):
#     _name = 'havi.checkvalue.abs'

#     user_id = fields.Many2one('res.partner')
#     modelname = fields.Char()
#     fieldname = fields.Char()
#     sourceid = fields.Integer()
#     valueid = fields.Integer()
#     valuestr = fields.Char()

# class CheckValue(models.TransientModel):
#     _name = 'havi.checkvalue'
#     _inherit = 'havi.checkvalue.abs'


class SaleOrderLine(models.Model):
    """Inherited For Sale Margin."""

    _inherit = 'sale.order.line'

    margin_in_per = fields.Char(compute='_get_line_margin_in_percentage',
                                string='Margin (%)',
                                store=True)

    # @api.one
    @api.depends('product_uom_qty', 'price_unit',
                 'discount', 'purchase_price')
    def _get_line_margin_in_percentage(self):
        sale_price = sale_cost = margin_in_per = 0.0
        # margin = (( sales price - cost ) / sales price ) * 100
        for rec in self:
            if rec.product_id:
                sale_price = rec.price_unit * rec.product_uom_qty
                # discount = (sale_price * rec.discount) / 100
                sale_cost = rec.purchase_price * rec.product_uom_qty
                # margin_amt = (sale_price - discount) - sale_cost
                if sale_cost and sale_price:
                    margin_in_per = \
                        ((sale_price - sale_cost) / sale_price) * 100
                else:
                    margin_in_per = 0.0
                rec.margin_in_per = round(margin_in_per, 2)


class SaleOrder(models.Model):
    """Inherited For Sale Margin."""

    _inherit = 'sale.order'

    foc_required = fields.Boolean(compute='_get_foc_required',
                                  string="Is FOC Required?",
                                  store=True)
    x_studio_branch = fields.Char(string="Branch")
    # Below field moved from studio to here need motification
    x_studio_foc = fields.Selection([
        ('r_and_d', 'R&D'),
        ('project_spares', 'Project Spares'),
        ('blacktown_hospital', 'Blacktown Hospital Rectification'),
        # ("specialised_projects", "Specialised Projects"),
        ("Sample", "Sample"),
        ("Marketing", "Marketing"),
        ("After Sales & Services", "After Sales & Services"),
        ("Special Arrangement", "Special Arrangement"),
        ("Swap Product", "Swap Product"),
        ("Kit items", "Kit items")], string="FOC")
    margin_in_per = fields.Float(compute='_get_margin_in_percentage',
                                 string='Margin (%)',
                                 store=True)

    # @api.multi
    @api.onchange('partner_id')
    def onchange_partner_id(self):
        """Onchange method to set the branch number."""
        super(SaleOrder, self).onchange_partner_id()
        self.x_studio_branch = \
            self.partner_id and self.partner_id.x_studio_branch or ''

    @api.onchange('x_studio_branch')
    def onchange_x_studio_branch(self):
        """Onchange method to set the partner based on the branch."""
        res_obj = self.env['res.partner']
        dom = []
        if self.x_studio_branch:
            dom.append(('x_studio_branch', '=', self.x_studio_branch))
            if self.company_id:
                dom.append(('company_id', '=',
                            self.company_id and self.company_id.id or False))
        if dom:
            partner = res_obj.search(dom, limit=1)
            if not partner:
                self.partner_id = False
            if partner:
                address = partner.address_get(['delivery', 'invoice'])
                # self.partner_id = address and \
                #     address.get('contact', False) or partner.id or False
                self.partner_id = partner and partner.id or False
                self.partner_invoice_id = address and \
                    address.get('invoice', False) or \
                    partner.id or False
                self.partner_shipping_id = address and \
                    address.get('delivery', False) or \
                    partner.id or False

    # @api.multi
    @api.depends('order_line', 'order_line.product_uom_qty',
                 'order_line.price_unit', 'order_line.discount',
                 'order_line.purchase_price')
    def _get_foc_required(self):
        """Method to get the status FOC Required or Not."""
        for sal_ord in self:
            sal_ord.foc_required = False
            price_tot = sal_ord.order_line and \
                sal_ord.order_line.mapped("price_unit")
            if sal_ord.order_line and sum(price_tot) <= 0.0:
                sal_ord.foc_required = True

    # @api.multi
    @api.depends('order_line', 'order_line.product_uom_qty',
                 'order_line.price_unit', 'order_line.discount',
                 'order_line.purchase_price')
    def _get_margin_in_percentage(self):
        sale_price = sale_cost = margin_in_per = 0.0
        # line_cost = sal_line_margin_amt = margin_in_per = 0.0
        # margin = (( sales price - cost ) / sales price ) * 100
        for rec in self:
            for sal_line in rec.order_line:
                sale_price += sal_line.price_unit * sal_line.product_uom_qty
                # discount = (sale_price * sal_line.discount) / 100
                sale_cost += sal_line.purchase_price * sal_line.product_uom_qty
                # line_cost += sale_cost
                # sal_line_margin_amt += (sale_price - discount) - sale_cost
            if sale_cost and sale_price:
                margin_in_per = ((sale_price - sale_cost) / sale_price) * 100
            else:
                margin_in_per = 0.0
            rec.margin_in_per = round(margin_in_per, 2)


    def client_order_ref_search(self, val, id):
        return self.env['sale.order'].search([
            ('client_order_ref', '=ilike', val),
            ('id', '!=', id)], limit=1)

    @api.onchange('client_order_ref')
    def onchange_client_order_ref(self):
        if self.client_order_ref:
            if self._origin.id:
                res = self.client_order_ref_search(self.client_order_ref,
                                                   self._origin.id)
            else:
                res = self.client_order_ref_search(self.client_order_ref, 0)
            if res:
                warning = {'warning': {
                    'title': _("Duplicated SO Found!!!"),
                    'message': _("Values '%s' was duplicated with"
                                 " SO: '%s' created by '%s' %"
                                 " (self.client_order_ref, res.name,"
                                 " res.create_uid.name)")
                }}
                if self._origin.id:
                    self.client_order_ref = self._origin.client_order_ref
                else:
                    self.client_order_ref = False
                return warning


    @api.depends('client_order_ref')
    def client_order_ref_check(self):
        return True

    def show_duplicate(self):
        hv_msg_obj = self.env['havi.message']
        if self._context.get('cus_ref_check'):
            return hv_msg_obj.with_context(sale_id=self.id).\
                action_confirm("Cannot open new Duplicated Window by"
                               " itself.\n\nDo you want to reopen"
                               " Duplicated Window",
                               "Duplicated Warning', 'hv_cus_ref_duplicate")

        cv = self.env['havi.checkvalue'].search([
            ('user_id', '=', self.env.user.id),
            ('modelname', '=', 'sale.order'),
            ('fieldname', '=', 'client_order_ref')], limit=1)
        if cv.valueid != self.id:
            return {
                'name': 'Duplicated Customer Reference',
                'view_type': 'form',
                'view_mode': 'form',
                'view_id': self.env.ref('sale.view_order_form').id,
                'res_model': 'sale.order',
                'type': 'ir.actions.act_window',
                'res_id': cv.valueid,
                'target': 'new',
                'context': {'cus_ref_check': True},
            }
        return {}
