# -*- coding: utf-8 -*-
"""Inherited For Account Invoice for Margin."""

from datetime import datetime
from odoo import api, fields, models



class AccountInvoiceLine(models.Model):
    _inherit = 'account.move.line'

    margin = fields.Float(compute='_get_invoice_line_margin_in_per', string='Margin Amount')
    margin_in_per = fields.Float(compute='_get_invoice_line_margin_in_per', string='Margin (%)')

    @api.depends('quantity', 'price_unit', 'discount')
    def _get_invoice_line_margin_in_per(self):
        sal_price = line_cost = margin_amt = margin_in_per = 0.0
        for inv_line in self:
            inv_line.margin = False
            inv_line.margin_in_per = False
            if inv_line.product_id:
                sal_price = inv_line.price_unit * inv_line.quantity
                std_amt = inv_line.product_id.standard_price if inv_line.product_id else 0.0
                line_cost = std_amt * inv_line.quantity
                margin_amt = sal_price - line_cost
                if line_cost and sal_price:
                    margin_in_per = ((sal_price - line_cost) / sal_price) * 100
                else:
                    margin_in_per = 0.0
                inv_line.margin = margin_amt if margin_amt else 0.0
                inv_line.margin_in_per = round(margin_in_per, 2)



class AccountInvoice(models.Model):
    _inherit = "account.move"

    margin = fields.Float(compute='_get_invoice_margin_in_percentage', string='Margin Amount')
    margin_in_per = fields.Float(compute='_get_invoice_margin_in_percentage', string='Margin (%)')

    @api.model
    def default_get(self, fields=[]):
        current_date = datetime.now().date()
        res = super(AccountInvoice, self).default_get(fields)
        if not res.get('invoice_date', False):
            res.update({'invoice_date': current_date})
        return res

    @api.depends('invoice_line_ids', 'invoice_line_ids.quantity', 'invoice_line_ids.price_unit', 'invoice_line_ids.discount')
    def _get_invoice_margin_in_percentage(self):
        inv_sal_price = inv_cost = line_margin_amount = line_cost = margin_in_per = 0.0
        for rec in self:
            rec.margin = False
            rec.margin_in_per = False
            if rec.invoice_line_ids:
                for inv_line in rec.invoice_line_ids:
                    inv_sal_price = inv_sal_price + (inv_line.price_unit * inv_line.quantity)
                    std_amt = inv_line.product_id.standard_price if inv_line.product_id else 0.0
                    inv_cost = inv_cost + (std_amt * inv_line.quantity)
                    line_margin_amount = line_margin_amount + inv_line.margin if inv_line.margin else 0.0
                if line_cost and inv_sal_price:
                    margin_in_per =  ((inv_sal_price - inv_cost) / inv_sal_price) * 100
                else:
                    margin_in_per = 0.0
                rec.margin = line_margin_amount
                rec.margin_in_per = round(margin_in_per, 2)