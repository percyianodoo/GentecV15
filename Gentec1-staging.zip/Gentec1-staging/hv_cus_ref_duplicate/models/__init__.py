# -*- coding: utf-8 -*-
"""Initialize Python files."""

from . import sale_margin
from . import account_invoice
from . import res_partner
