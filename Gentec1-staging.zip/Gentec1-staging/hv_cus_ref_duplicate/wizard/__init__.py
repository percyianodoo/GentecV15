# -*- coding: utf-8 -*-
"""Initialize Python files."""

from . import sale_make_invoice_advance
