# -*- coding: utf-8 -*-
import base64
import itertools
import unicodedata
import chardet
import io
import operator

from datetime import datetime, date, timedelta
from itertools import groupby
from odoo.exceptions import UserError, ValidationError
from odoo import api, exceptions, fields, models, _
from odoo.tools.mimetypes import guess_mimetype
from odoo.tools import config, DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT, pycompat

try:
    import xlrd
    try:
        from xlrd import xlsx
    except ImportError:
        xlsx = None
except ImportError:
    xlrd = xlsx = None

try:
    from . import odf_ods_reader
except ImportError:
    odf_ods_reader = None

FILE_TYPE_DICT = {
    'text/csv': ('csv', True, None),
    'application/vnd.ms-excel': ('xls', xlrd, 'xlrd'),
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ('xlsx', xlsx, 'xlrd >= 1.0.0'),
    'application/vnd.oasis.opendocument.spreadsheet': ('ods', odf_ods_reader, 'odfpy')
}

MAP_INVOICE_TYPE_PARTNER_TYPE = {
    'out_invoice': 'customer',
    'out_refund': 'customer',
    'in_invoice': 'supplier',
    'in_refund': 'supplier',
}

MAP_INVOICE_TYPE_PAYMENT_SIGN = {
    'out_invoice': 1,
    'in_refund': -1,
    'in_invoice': -1,
    'out_refund': 1,
}

OPTIONS = {
    'advanced': False,
    'bank_stmt_import': True, 'date_format': '',
    'datetime_format': '', 'encoding': 'ascii',
    'fields': [], 'float_decimal_separator': '.',
    'float_thousand_separator': ',', 'headers': True,
    'keep_matches': False,
    'name_create_enabled_fields': {'currency_id': False, 'partner_id': False},
    'quoting': '"', 'separator': ','
}


class hv_customer_account_invoice(models.Model):
    _inherit = 'account.move'

    client_order_ref = fields.Char(compute='get_client_order_ref')

    # @api.multi
    def get_client_order_ref(self):
        for invoice in self:
            if invoice.sale_id:
                sale_order = self.env['sale.order'].search([('name', '=', invoice.sale_id.name)], limit=1)
                invoice.client_order_ref = sale_order and sale_order.client_order_ref or ''
            else:
                invoice.client_order_ref = ""

    def _search_id(self, query):
        if not query:
            return []
        self._cr.execute(query)
        res = self._cr.fetchall()
        if not res:
            return []
        return [[r[0], r[1], r[2]] for r in res]

    def action_invoice_sent(self):
        """Overridden method to segrigate the compose mail lables."""
        result = super(hv_customer_account_invoice, self).action_invoice_sent()
        TYPES = {
            'out_invoice': _('Invoice'),
            'in_invoice': _('Vendor Bill'),
            'out_refund': _('Credit Note'),
            'in_refund': _('Vendor Credit note'),
        }
        if self.move_type and self.move_type == 'out_refund':

            template = self.env.ref('hv_customer_statement.email_tmpl_credit_note_invoice', False)
            lang = self.env.context.get('lang')
            if template and template.lang:
                lang = self.env['ir.ui.view']._render_template('hv_customer_statement.email_tmpl_credit_note_invoice')
            self = self.with_context(lang=lang)
            result.update({'name': _('Send Credit Note')})
            ctx = dict(
                default_model='account.move',
                default_res_id=self.id,
                default_use_template=bool(template),
                default_template_id=template and template.id or False,
                default_composition_mode='comment',
                mark_invoice_as_sent=True,
                model_description=TYPES[self.move_type],
                custom_layout="mail.mail_notification_paynow",
                force_email=True
            )
            result.update({'context': ctx})
        return result


class hv_customer_statement_line(models.Model):
    _name = 'hv.customer.statement.line'
    _description = 'Customer Statement Line'

    customer_id = fields.Many2one('res.partner', string='Customer', domain="[('parent_id', '=', False)]")
    move_line_ids = fields.Many2many('account.move.line')
    email_address = fields.Char(string='Email')
    total = fields.Float(string='Balance', readonly=True, compute='_compute_values')
    balance = fields.Float(string='Balance', readonly=True, compute='_compute_values')
    overdue = fields.Float(string='Overdue', readonly=True, compute='_compute_values')
    statement_id = fields.Many2one('hv.customer.statement')
    email_send = fields.Integer(string='Send Times', default=0, readonly=True)
    send_check = fields.Boolean(string='Send', default=False)
    parent_id = fields.Many2one('hv.customer.statement.line', index=True, ondelete='cascade')
    child_ids = fields.One2many('hv.customer.statement.line', 'parent_id', index=True, ondelete='cascade')
    consolidatedsm = fields.Boolean(default=lambda self: self.get_consolidatedsm())
    company_id = fields.Many2one('res.company', string='Company', change_default=True, default=lambda self: self.env['res.company']._company_default_get('hv.customer.statement.line'))

    _sql_constraints = [
        ('unique_customer_id', 'unique (customer_id,statement_id,parent_id)',
         'A Customer can be added only once !'),
    ]

    def get_consolidatedsm(self):
        if not self._context.get('default_statement_id'):
            return True
        return self.env['hv.customer.statement'].browse(self._context.get('default_statement_id')).consolidatedsm

    @api.onchange('customer_id')
    def onchange_customer_id(self):
        if self.customer_id:
            self.email_address = self.customer_id.email

    # @api.one
    @api.depends('customer_id')
    def _compute_values(self):
        for rec in self:
            if rec.customer_id:
                if rec.consolidatedsm:
                    rec.search_all_invoice()
                else:
                    rec.search_invoice()
            rec.balance = 0
            rec.overdue = 0
            if rec.move_line_ids:
                rec.total += sum([i.move_id.amount_total_signed if i.move_id else i.amount_residual_currency if i.currency_id else i.amount_residual for i in rec.move_line_ids if not i.blocked])
                rec.balance += sum([i.move_id.amount_residual_signed if i.move_id else i.amount_residual_currency if i.currency_id else i.amount_residual for i in rec.move_line_ids if not i.blocked])
                rec.overdue += sum([i.move_id.amount_residual_signed for i in rec.move_line_ids if (
                    i.move_id and i.move_id.invoice_date_due < fields.Date.today()) and not i.blocked])
        return True

    def search_invoice(self):
        if self.customer_id:
            start_date = self.statement_id.start_date
            statement_date = self.statement_id.statement_date
            if start_date == statement_date:
                start_date = start_date - timedelta(days=3650)
            query = """
                    SELECT max(m.id), max(m.id), max(m.id)
                    from account_move_line m
                        inner join account_move i on m.move_id=i.id and i.amount_total_signed!=0 and i.state='posted'
	                    inner join account_account a on m.account_id = a.id
		                    and a.deprecated=false and a.internal_type ='receivable'
                    where m.reconciled=false and m.blocked=false
                        and m.date  >= '%s' and m.date <= '%s'
                        and (i.partner_id = %s)
                        and (m.company_id = %s)
                        and m.move_id is not null
                        group by m.move_id
                    union all
                    SELECT (m.id), (m.id), (m.id)
                    from account_move_line m
	                    inner join account_account a on m.account_id = a.id
		                    and a.deprecated=false and a.internal_type ='receivable'
                    where m.reconciled=false and m.blocked=false
                        and m.date  >= '%s' and m.date <= '%s'
                        and (m.partner_id = %s)
                        and (m.company_id = %s)
                        and m.move_id is null
                    """ % (start_date, statement_date , self.customer_id.id,
                           self.company_id and self.company_id.id or False,
                           start_date, statement_date, self.customer_id.id,
                           self.company_id and self.company_id.id or False)
            move_line_ids = self.env['account.move']._search_id(query)
            self.move_line_ids = [(6, 0, [r[0] for r in move_line_ids])]

    def search_all_invoice(self):
        if self.customer_id:
            start_date = self.statement_id.start_date
            statement_date = self.statement_id.statement_date
            if start_date == statement_date:
                start_date = start_date - timedelta(days=3650)
            query = """
                    SELECT max(m.id), max(m.id), max(m.id)
                    from account_move_line m
                        inner join account_move i on m.move_id=i.id and i.amount_total_signed!=0 and i.state='posted'
	                    inner join account_account a on m.account_id = a.id
		                    and a.deprecated=false and a.internal_type ='receivable'
                    where m.reconciled=false and m.blocked=false
                        and m.date >= '%s' and m.date  <= '%s'
                        and (m.partner_id = %s)
                        and (m.company_id = %s)
                        and m.move_id is not null
                        group by m.move_id
                    union all
                    SELECT (m.id), (m.id), (m.id)
                    from account_move_line m
	                    inner join account_account a on m.account_id = a.id
		                    and a.deprecated=false and a.internal_type ='receivable'
                    where m.reconciled=false and m.blocked=false
                    and m.date  >= '%s' and m.date  <= '%s'
                        and (m.partner_id = %s)
                        and (m.company_id = %s)
                        and m.move_id is null
                    """ % (start_date, statement_date, self.customer_id.id,
                           self.company_id and self.company_id.id or False,
                           start_date, statement_date, self.customer_id.id,
                           self.company_id and self.company_id.id or False)
            move_line_ids = self.env['account.move']._search_id(query)
            self.move_line_ids = [(6, 0, [r[0] for r in move_line_ids])]

    def print_customer_statement(self):
        if self.consolidatedsm:
            self.search_all_invoice()
        else:
            self.search_invoice()
        if self.move_line_ids:
            return self.env.ref('hv_customer_statement.action_report_customer_statement').report_action(self)


class hv_customer_statement(models.Model):
    _name = 'hv.customer.statement'
    _description = 'Customer Statement'

    statement_date = fields.Date(string='Statement Date', required=True, default=fields.Date.today())
    start_date = fields.Date(string='Start Date', required=True, default=fields.Date.today())
    emailtemplate = fields.Many2one('mail.template', string='Template')
    include0balance = fields.Boolean(string='Include 0 Balance', default=False)
    showonlyopen = fields.Boolean(string='Show Only Open Transaction', default=False)
    consolidatedsm = fields.Boolean(string='Consolidated Statement', default=True, readonly=True)
    line_ids = fields.One2many('hv.customer.statement.line', 'statement_id', string='Customers', domain=lambda self: [('consolidatedsm', '=', self.consolidatedsm)])
    selectall = fields.Boolean(default=False, compute="check_select")
    company_id = fields.Many2one('res.company', string='Company', change_default=True, default=lambda self: self.env['res.company']._company_default_get('hv.customer.statement'))

    @api.depends("consolidatedsm")
    def check_select(self):
        self.selectall = True
        for l in self.line_ids:
            if not l.send_check:
                self.selectall = False
                break

    def set_consolidated(self):
        self.consolidatedsm = not self.consolidatedsm

    def select_all(self):
        self.selectall = not self.selectall
        for l in self.line_ids:
            l.send_check = self.selectall

    def get_detail(self):
        lself = self.env['hv.customer.statement.line'].search([('statement_id', '=', self.id), ('consolidatedsm', '=', True)])
        if lself:
            for l in lself:
                if not l.consolidatedsm:
                    continue
                l.search_all_invoice()
                for dt in l.child_ids:
                    ex = False
                    for item in groupby(l.move_line_ids, lambda i: i.move_id.partner_id if i.move_id else i.partner_id):
                        if item[0].id == dt.customer_id.id:
                            ex = True
                            break
                    if not ex:
                        dt.unlink()
                        l.child_ids -= dt

                for item in groupby(l.move_line_ids, lambda i: i.move_id.partner_id if i.move_id else i.partner_id):
                    ex = False
                    for dt in l.child_ids:
                        if item[0].id == dt.customer_id.id:
                            ex = True
                            break
                    if not ex:
                        self.env['hv.customer.statement.line'].create({
                            'customer_id': item[0].id,
                            'email_address': item[0].email,
                            'parent_id': l.id,
                            'statement_id': l.statement_id.id,
                            'consolidatedsm': False,
                        })
        

    def partner_by_invoice(self):
        if self.statement_date:
            start_date = self.start_date
            statement_date = self.statement_date
            if start_date == statement_date:
                start_date = start_date - timedelta(days=3650)
            query = """
                    select id, email,1 from res_partner where id in
                    (select COALESCE(pa.parent_id,pa.id)
                        FROM account_move_line m
                            inner join res_partner pa on m.partner_id = pa.id
                            inner join account_account a on m.account_id = a.id
                                and a.deprecated=false and a.internal_type ='receivable'
                        where m.reconciled=false and m.blocked=false
                            and m.date >= '%s' and m.date <= '%s' and
                            m.company_id = '%s')
                    """ % (start_date, statement_date,
                           self.company_id and self.company_id.id or False)
            partner_ids = self.env['account.move']._search_id(query)
            lself = self.env['hv.customer.statement.line'].search(
                [('statement_id', '=', self.id),
                 ('consolidatedsm', '=', True)])
            for l in lself:
                if not l.consolidatedsm:
                    continue
                ex = False
                for dt in partner_ids:
                    if l.customer_id.id == dt[0]:
                        ex = True
                        break
                if not ex:
                    l.unlink()
                    lself -= l

            for item in partner_ids:
                ex = False
                for dt in lself:
                    if item[0] == dt.customer_id.id:
                        ex = True
                        break
                if not ex:
                    self.env['hv.customer.statement.line'].create({
                        'customer_id': item[0],
                        'email_address': item[1],
                        'statement_id': self.id,
                        'consolidatedsm': True,
                    })
            self.get_detail()
        return self.env['havi.message'].action_warning('Update Partner List completed', 'Customer Statement')

    def send_mail_customer_statement(self):
        default_template = self.env.ref(
            'hv_customer_statement.email_template_customer_statement', False)
        for item in self.line_ids:
            if not item.send_check:
                continue
            if self.consolidatedsm:
                item.search_all_invoice()
            else:
                item.search_invoice()
            if item.move_line_ids:
                ctx = dict(
                    active_model='hv.customer.statement.line',
                    active_id=item.id,
                    default_model='hv.customer.statement.line',
                    default_res_id=item.id,
                    default_use_template=bool(default_template),
                    default_template_id=default_template and default_template.id or False,
                    default_composition_mode='mass_mail',
                )
                wizard_mail = self.env['mail.compose.message'].with_context(ctx).create({})
                wizard_mail.onchange_template_id_wrapper()
                wizard_mail.send_mail()
                item.email_send += 1

        return self.env['havi.message'].action_warning('Send customer statement completed', 'Customer Statement')
