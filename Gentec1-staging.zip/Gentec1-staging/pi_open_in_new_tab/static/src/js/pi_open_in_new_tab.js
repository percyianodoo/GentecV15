odoo.define('open_in_new_tab.new_tab', function(require) {
"use strict";
var core = require('web.core');
var Widget = require('web.Widget');
var BasicRenderer = require('web.BasicRenderer');
var ListRenderer = require('web.ListRenderer');
var ListController = require('web.ListController');
var AbstractController = require('web.AbstractController');
var core = require('web.core');
var Dialog = require('web.Dialog');
var _t = core._t;
var qweb = core.qweb;
var tab_limit = 8;

AbstractController.include({            // Trigger up function for new tab

     init: function (parent, model, renderer, params) {
        this.custom_events['open_in_new_tab'] = "_open_in_new_tab";
        this._super.apply(this, arguments);
        this.action_manager = parent;
    },

    _open_in_new_tab: function (event) {
        event.stopPropagation();
        var record = this.model.get(event.data.id, {raw: true});
        var getUrl = window.location;
        var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
        var model_name = record.model;
        var action_id = '';
        if(this.importEnabled){
            this.do_action({ type: 'ir.actions.act_url',
                url:baseUrl+'#id='+record.res_id+'&view_type=form&model='+model_name+'&action='+action_id,
                target: 'new'
             });
        }else{
              this.do_action({ type: 'ir.actions.act_url',
              url:baseUrl+'#id='+record.res_id+'&view_type=form&model='+model_name, //+'&action='+action_id,
              target: 'new'
             });

        };

    },
});

ListRenderer.include({              // Add the icon and th and fooder
    _renderHeader: function (isGrouped) {          //over ride the base funcions
        // Todo : Get the tr element and append <th>

        var $tr = $('<tr>').append(_.map(this.columns, this._renderHeaderCell.bind(this)));
      if (this.hasSelectors) {
            $tr.prepend(this._renderSelector('th'));
            $tr.append($('<th>').html('&nbsp;'));
       }else{
            var $tr = $('<tr>').append(_.map(this.columns, this._renderHeaderCell.bind(this)));
            $tr.append($('<th>').html('&nbsp;'));
       }
       return $('<thead>').append($tr);
    },

//       if (isGrouped) {
//            $tr.prepend($('<th>').html('&nbsp;'));
//        }

    _renderFooter: function (isGrouped) {
        var aggregates = {};
        _.each(this.columns, function (column) {
            if ('aggregate' in column) {
                aggregates[column.attrs.name] = column.aggregate;
            }
        });
        var $cells = this._renderAggregateCells(aggregates);
        if (isGrouped) {
            $cells.unshift($('<td>'));
        }
        if (this.hasSelectors) {
            $cells.unshift($('<td>'));
        }
        return $('<tfoot>').append($('<tr>').append($cells).append("<td>"));
    },

    _renderRow: function (record, index) {
        var $row = this._super.apply(this, arguments);
           $row.append('<td class="fa fa-external-link" id="new_tab" />');
        return $row;
    },
    _onRowClicked: function (event) {
        var currentTargetId = $(event.target).attr("id");
        if(currentTargetId == 'new_tab'){
            var id = $(event.currentTarget).data('id');
            if (id) {
                this.trigger_up('open_in_new_tab', {id:id, target: event.target});
            }
        }
        else{
            if (!event.target.closest('.o_list_record_selector') && !$(event.target).prop('special_click') && !this.no_open) {
                var id = $(event.currentTarget).data('id');
                if (id) {
                    this.trigger_up('open_record', {id:id, target: event.target});
                }
            }
        }
    },
});

ListController.include({
    init: function (parent, model, renderer, params) {
            this._super.apply(this, arguments);
    },

 // Todo : include the side bar instead of overriding function
    _getActionMenuItems: function (state) {
        const { isM2MGrouped } = state;
        if (!this.hasActionMenus || !this.selectedRecords.length) {
            return null;
        }
        const props = this._super(...arguments);
        const otherActionItems = [];
        if (this.isExportEnable) {
            otherActionItems.push({
                description: _t("Export"),
                callback: () => this._onExportData()
            });
        }

        otherActionItems.push({
                    description: _t("Open in New Tab"),
                    callback: this._open_new_tab.bind(this, true)
                });

        if (this.archiveEnabled && !isM2MGrouped) {
            otherActionItems.push({
                description: _t("Archive"),
                callback: () => {
                    const dialog = Dialog.confirm(this, _t("Are you sure that you want to archive all the selected records?"), {
                        confirm_callback: () => {
                            this._toggleArchiveState(true);
                            dialog.close();
                        },
                    });
                }
            }, {
                description: _t("Unarchive"),
                callback: () => this._toggleArchiveState(false)
            });
        }
        if (this.activeActions.delete && !isM2MGrouped) {
            otherActionItems.push({
                description: _t("Delete"),
                callback: () => this._onDeleteSelectedRecords()
            });
        }
        return Object.assign(props, {
            items: Object.assign({}, this.toolbarActions, { other: otherActionItems }),
            context: state.getContext(),
            domain: state.getDomain(),
            isDomainSelected: this.isDomainSelected,
        });
    },

    _open_new_tab: function () {
         var link_array = Array();
         var ids =this.getSelectedIds();
         var record = this.model.get(this.handle);
         var model = record.model;
         var action_id = '';
         var tab_arr = "";
         for (var a in ids   ) {
                var getUrl = window.location;
                var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1];
                var url = baseUrl+'#id='+ids[a]+'&view_type=form&model='+model+'&action='+action_id;
                link_array.push(url);
                tab_arr += "window.open('" + url +"', '_blank');";
        }
        if(link_array.length <= tab_limit ){
            eval(tab_arr + "");
        }else{
            this.displayNotification({
                title: _t(" Maximum 8 records  are allowed."),
                type: 'danger',
            })
        }
    },
});
});

