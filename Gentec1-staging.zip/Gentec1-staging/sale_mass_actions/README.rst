.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

=======================
Sale Order Mass Action for Odoo 11 EE&CE
=======================


This module allows a Draft or massive Confirmation of sale orders.


Configuration
=============

To configure this module, you need to:

#. No configuration needed. Just install the module.

Usage
=====

To use this module, you need to:

#. Open the tree view of sale orders.
#. Select the sale orders you want to confirm or set to Draft .
#. In the More menu select Confirm Sale Orders.
#. In the pop-up press Confirm.


Credits
=======

Contributors
------------

* Mahmoud Abdel Latif <http://mah007.com>
* phone : +201002688172
