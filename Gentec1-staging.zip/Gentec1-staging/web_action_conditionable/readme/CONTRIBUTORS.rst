* Cristian Salamea <cristian.salamea@gmail.com>
* André Paramés <github@andreparames.com> (https://www.acsone.eu/)
