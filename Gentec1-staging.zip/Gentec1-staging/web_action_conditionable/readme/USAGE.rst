This module has no direct interface, it only adds functionality for custom views.
