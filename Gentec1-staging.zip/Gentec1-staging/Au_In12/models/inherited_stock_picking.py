"""Stock Picking Model."""

from odoo import api, fields, models, _


class Picking(models.Model):
    _inherit = "stock.picking"

    invoice_count = fields.Integer(string='# of Invoices', compute='_get_invoiced',)
    invoice_ids = fields.Many2many('account.move', string='# of Invoices', compute='_get_invoiced',)
    
    @api.depends('state')
    def _get_invoiced(self):
        for order in self:
            invoices = self.env['account.move'].search([('picking_id', '=', self.id)])
            if invoices:
                order.invoice_ids = invoices.ids
                order.invoice_count = len(invoices)
            else:
                order.invoice_ids = None
                order.invoice_count = None

    def button_view_invoice(self):
        self.ensure_one()
        view_form_id = self.env.ref('account.view_move_form').id
        view_kanban_id = self.env.ref('account.view_out_invoice_tree').id
        action = {
            'type': 'ir.actions.act_window',
            'domain': [('id', 'in', self.invoice_ids.ids)],
            'view_mode': 'kanban,form',
            'name': _('Invoice'),
            'res_model': 'account.move',
        }
        if len(self.invoice_ids) == 1:
            action.update({'views': [(view_form_id, 'form')], 'res_id': self.invoice_ids.id})
        else:
            action['views'] = [(view_kanban_id, 'kanban'), (view_form_id, 'form')]
        return action

    def _action_done(self):
        super(Picking, self)._action_done()
        if self.state == 'done':
            if self.picking_type_id.code == 'incoming':
                purchase = self.purchase_id
                vals = {
                    'move_type': 'in_invoice',
                    'invoice_origin': self.origin,
                    'pur_id': purchase and purchase.id or False,
                    'purchase_id': purchase and purchase.id or False,
                    'partner_id': self.partner_id and self.partner_id.id or False,
                    'picking_id': self.id
                }
                res = self.env['account.move'].create(vals)
                res._onchange_purchase_auto_complete()
                # res.compute_taxes()
                res._onchange_partner_id()
                for inv_line in res.invoice_line_ids:
                    if inv_line.quantity <= 0:
                        inv_line.unlink()

            if self.picking_type_id.code == 'outgoing':
                inv_obj = self.env['account.move']
                account_move_line_obj = self.env['account.move.line']
                sale_order = self.env['sale.order'].search([('name', '=', self.origin)], limit=1)
                delivery_partner = self.partner_id
                if sale_order:
                    # bank_acc = inv_obj._get_default_bank_id(
                    #     'out_invoice',
                    #     self.company_id and self.company_id.id)
                    invoice = inv_obj.create({
                        'invoice_origin': self.origin,
                        'picking_id': self.id,
                        'move_type': 'out_invoice',
                        'payment_reference': False,
                        'sale_id': sale_order.id,
                        'partner_id': sale_order.partner_id and
                        sale_order.partner_id.id or
                        sale_order.partner_invoice_id and
                        sale_order.partner_invoice_id.id or False,
                        'partner_shipping_id':
                        sale_order.partner_shipping_id and
                        sale_order.partner_shipping_id.id or
                        delivery_partner and delivery_partner.id or False,
                        'currency_id': sale_order.pricelist_id.currency_id.id,
                        'invoice_payment_term_id': sale_order.payment_term_id.id,
                        'fiscal_position_id': sale_order.fiscal_position_id and
                        sale_order.fiscal_position_id.id or
                        sale_order.partner_id and
                        sale_order.partner_id.property_account_position_id.id,
                        'team_id': sale_order.team_id.id,
                        'narration': sale_order.note,
                        # 'partner_bank_id': bank_acc and bank_acc.id or False,
                        'narration': fields.Datetime.now().date()
                    })
                    inv_line = False
                    for sale_line in self.move_lines:
                        if sale_line.product_id.property_account_income_id:
                            account = sale_line.product_id and \
                                sale_line.product_id.property_account_income_id
                        elif sale_line.product_id.categ_id.property_account_income_categ_id:
                            account = sale_line.product_id and sale_line.product_id.categ_id.property_account_income_categ_id
                        else:
                            account_search = self.env['ir.property'].search([('name', '=', 'property_account_income_categ_id')])
                            account = account_search.value_reference
                            account = account.split(",")[1]
                            account = self.env['account.account'].browse(account)
                        inv_line = account_move_line_obj.create({
                            'name': sale_line.name,
                            'account_id': account.id,
                            'price_unit': sale_line.price_unit * -1,
                            'quantity': sale_line.product_uom_qty,
                            'product_uom_id': sale_line.product_id.uom_id.id,
                            'product_id': sale_line.product_id.id,
                            'move_id': invoice.id,
                        })
                        order_line = self.env['sale.order.line'].search([('order_id', '=', sale_order.id),
                             ('product_id', '=', sale_line.product_id.id)])
                        if inv_line:
                            for line in order_line:
                                line.write({
                                    'qty_to_invoice': sale_line.product_uom_qty,
                                    'invoice_lines': [(4, inv_line.id)]
                                })

                            tax_ids = []
                            if order_line and order_line[0]:
                                for tax in order_line[0].tax_id:
                                    tax_ids.append(tax.id)
                                    inv_line.write({
                                        'price_unit': order_line[0].price_unit,
                                        'discount': order_line[0].discount,
                                        'invoice_line_tax_ids': [(6, 0, tax_ids)]
                                    })
        return True
