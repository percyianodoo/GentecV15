# -*- encoding: utf-8 -*-
"""Initialize python files."""

from . import product
from . import sale_order
