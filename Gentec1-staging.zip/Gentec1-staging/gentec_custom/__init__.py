# -*- encoding: utf-8 -*-
"""Initialize model files."""

from . import models
