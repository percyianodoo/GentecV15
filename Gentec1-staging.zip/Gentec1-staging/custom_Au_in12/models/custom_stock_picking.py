
from odoo import api, fields, models, _

class StockPicking(models.Model):
    _inherit = "stock.picking"

    def _action_done(self):
        res = super(StockPicking, self)._action_done()
        picking = self.browse(self._context.get('button_validate_picking_ids')[0])
        sale_order  =  self.env['sale.order'].search([('name', '=', picking.origin)])
        account = None
        if sale_order:
            inv = self.env['account.move'].search([('sale_id','=',self.origin)],limit=1)
            for sale_line in picking.move_lines:
                if sale_line.product_id.property_account_income_id:
                    account = sale_line.product_id.property_account_income_id
                elif sale_line.product_id.categ_id.property_account_income_categ_id:
                    account = sale_line.product_id.categ_id.property_account_income_categ_id
            for inv_line in inv.invoice_line_ids:
                inv_line.unlink()
            for sale_lines in sale_order.order_line:
                if not account:
                    account_search = self.env['ir.property'].search([('name', '=', 'property_account_income_categ_id')])
                    account = account_search.value_reference
                    account = account.split(",")[1]
                    account = self.env['account.account'].browse(account)
                inv.invoice_line_ids = [(0, 0, {'product_id': sale_lines.product_id.id, 
                                    'name':sale_lines.name,
                                    'price_unit':sale_lines.price_unit,
                                    'quantity' : sale_lines.product_uom_qty,
                                    'account_id': account.id,
                                    'move_id':inv.id})]
                # sale_lines.write({'qty_invoiced': inv.invoice_line_ids.quantity})
            return res
        else:
            return res
