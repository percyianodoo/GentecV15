# -*- coding: utf-8 -*-
from odoo import fields, models, _


class hv_credit_limit_sale_order_confirm(models.TransientModel):
    _name = 'sale.order.confirm'
    _description = 'Sale Order Confirm'

    _message = fields.Text(readonly=True)

    def action_overwrite(self):
        sale = self.env['sale.order'].browse(self._context.get('sale_id'))
        sale.confirm_result = 1
        sale.action_confirm()